package alixar.examenJava;

import java.util.Scanner;

public class Actividad2 {
  static public void main(String[] args) {
    // Escribe un programa que diga si un número introducido por teclado es o no capicúa. Los
    // números capicúa se leen igual hacia delante y hacia atrás. El programa debe aceptar números
    // de cualquier longitud siempre que lo permita el tipo, en caso contrario el ejercicio no se
    // dará por bueno. Se recomienda usar long en lugar de int ya que el primero admite números más
    // largos.
    //
    // NOTA: No puedo utilizar funciones de cadenas.

      long num, a, reves = 0, cifra;
      Scanner teclado = new Scanner(System.in);
      do {
          System.out.print("Introduce un número >= 10: ");
          num = teclado.nextLong();
      } while (num < 10);

      //le damos la vuelta al número
      a = num;
      while (a!=0){
          cifra = a % 10;
          reves = reves * 10 + cifra;
          a = a / 10;
      }

      //Se realiza la verificacion si el numero es capicua
      if(num == reves){
          System.out.println("Es capicua");
      }else{
          System.out.println("No es capicua");
      }

  }
}
