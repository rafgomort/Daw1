package alixar.examenJava;

import java.util.Scanner;

public class Actividad4 {
  static public void main(String[] args) {
      // Crear programa que pinte una flecha doble hacia la izquierda. Se pide al usuario la altura de
      // la figura, que debe ser un número impar mayor o igual que 3. La distancia entre cada flecha
      // de asteriscos es siempre de 5 espacios. Si la altura introducida por el usuario no es un
      // número impar mayor o igual que 3, el programa debe mostrar un mensaje de error.
      //
      // Ejemplo 1:
      //
      // Introduce la altura de la flecha: 7

      Scanner teclado=new Scanner(System.in);
      System.out.println("Introduce la altura");
      int altura=teclado.nextInt();
      boolean correcto=false;

      do {
          System.out.print("Introduce el número de filas (mayor o igual que 3 y que sea impar): ");
          altura = teclado.nextInt();
          if(altura>=0 && altura%2!=0){
              correcto = true;
          }
      } while (!correcto);

      //Quiero averiguart el asterisco
        for(int i=1; i>1;i++){
            i=i+5;
            System.out.print("*");
        }

        for(int j=0;j>altura;j++){

        }

  }
}
