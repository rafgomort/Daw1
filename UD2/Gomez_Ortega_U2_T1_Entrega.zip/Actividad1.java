package alixar.examenJava;

import java.util.Scanner;

public class Actividad1 {
  static public void main(String[] args) {
    // Calcula la nota de un trimestre de la asignatura Programación. El programa pedirá las tres
    // notas que ha sacado el alumno en los tres primeros controles.
    // Si la media de los tres controles da un número mayor o igual a 5, el alumno está aprobado y se
    // mostrará la media y la nota correspondiente .Atendiendo a esa media el alumno tendrá las
    // siguientes notas:
    //
    // Suficiente si la media en mayor o igual que 5 y menor que 6.
    // Bien si la media es mayor o igual que 6 y menor que 7.
    // Notable si la media es mayor o igual que 7 y menor que 9.
    // Sobresaliente en cualquier otro caso.
    // En caso de que la media sea un número menor que 5, el alumno habrá tenido que hacer el examen
    // de recuperación que se califica como apto o no apto, por tanto se debe preguntar al usuario
    // ¿Cuál ha sido el resultado de la recuperación? (apto/no apto). Si el resultado de la recuperación
    // es apto, la nota será un 5; en caso contrario, se mantienela nota media anterior.

      Scanner teclado= new Scanner(System.in);
      System.out.println("Introduce la primera nota de programación");
      int num1=teclado.nextInt();
      teclado.nextLine();
      System.out.println("Introduce la segunda nota de programación");
      int num2= teclado.nextInt();
      teclado.nextLine();
      System.out.println("Introduce la tercera nota de programación");
      int num3=teclado.nextInt();
      teclado.nextLine();
      double media=(double)(num1+num2+num3)/3;


      System.out.println("Nota del primer control: " +num1);
      System.out.println("Nota del segundo control: " +num2);
      System.out.println("Nota del tercero control: " +num3);
      System.out.println("Tu nota de Programación es " +media);

      if(media>=5 && media<6){
          System.out.println("Tienes un " + media + " es decir, un Suficiente");
    } else {
      if (media >= 6 && media < 7) {
        System.out.println("Tienes un " + media + " es decir Bien");
      } else {
        if (media >= 7 && media < 9) {
          System.out.println("Tienes un " + media + " es decir, un Notable");
        } else {
          if (media > 9 && media == 10) {
            System.out.println("Ehnorabuena has sacado un " + media + " Sobresaliente");
          } else {
            System.out.println("¿Cuál ha sido el resultado de la recuperación?(apto/no apto)");
            String recu = teclado.next();
            teclado.nextLine();

            if (recu.equals("apto"))  {
              System.out.println("Tu nota de programación es 5 ");
              teclado.nextLine();
            }else{
                if(recu.equals("no apto")){
                    System.out.println("Tu nota de Progrmación es " +media);
                    teclado.nextLine();
                }
            }
            }
          }
        }
      }
  }
}
