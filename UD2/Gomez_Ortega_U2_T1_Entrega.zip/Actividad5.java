package alixar.examenJava;

import java.util.Scanner;

public class Actividad5 {
  static public void main(String[] args) {
      // Escribe un programa que lea una cadena y luego escriba un rombo usando los caracteres de la
      // cadena
      //
      // Por ejemplo si la cadena leida es "Sample" el resultado debe ser:
      // NOTA: Si la cadena tiene más de 10 caracteres de longitud debo usar los 10 primero nada más.

      Scanner teclado=new Scanner(System.in);
      boolean numeroCorrecto = false;
      int numFilasRombos;
      do {
          System.out.print("Introduce el número de filas: ");
          numFilasRombos = teclado.nextInt();
          if(numFilasRombos>0 && numFilasRombos%2!=0){
              numeroCorrecto = true;
          }
      } while (!numeroCorrecto);

      System.out.println("");

      int numFilas = numFilasRombos/2 + 1;

      String palabra=teclado.next();
      System.out.println("Introduce una palabra ");
      for(int altura=1;altura<=numFilas;altura++){

          //hueco
          for(int hueco=1;hueco<=numFilas-altura;hueco++){
              System.out.print(" ");
          }

          //palabra
          for(int pal=1;pal<=(2*altura)-1;pal++){
              System.out.print(palabra.charAt(0));

          }
          System.out.println("");
      }

      numFilas--;

      for (int altura = 1; altura <= numFilas; altura++) {
          // Blancos
          for (int blancos = 1; blancos <= altura; blancos++) {
              System.out.print(" ");
          }
          // palabra
          for (int asteriscos = 1; asteriscos <= (numFilas - altura) * 2 + 1; asteriscos++) {
              System.out.print(palabra.charAt(0));
          }
          System.out.println();
      }
  }
}
