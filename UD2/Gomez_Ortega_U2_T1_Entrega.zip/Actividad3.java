package alixar.examenJava;

import java.util.Scanner;

public class Actividad3 {
    static public void main(String[]args){
        //Realiza un programa lea un número entero positivo de la pantalla y que lo pase a binario.

        Scanner teclado=new Scanner(System.in);
        System.out.println("Introduce un numero entero positivo");
        int num=teclado.nextInt();

        String binario="";

        System.out.println("El numero " + num + " en binario es: ");
        for(int i=8;i>=0;i--){
            if(num>=Math.pow(2, i)){
                num-=Math.pow(2,i);
                binario=binario.concat("1");
            }else{
                binario=binario.concat("0");
            }
        }
        System.out.println(binario);

    }
}
